function [Q] = confusionmatrix(predicted,true)
%CONFUSTION_MATRIX Summary of this function goes here
% Detailed explanation goes here
for i = 1:2
    for j = 1:2  
        Q(i,j) = sum((true==i-1 & predicted==j-1));
    end
end

